/*
 * File:   FSM.c
 * Author: Dell
 *
 * Created on November 18, 2019, 10:31 AM
 */


#include <xc.h>
#include "button.h"
#include "variables.h"
#include "time_manager.h"
#include "pin_manager.h"

void FSM(void) { 
    switch(state_machine){
        case IDLE:
            switch_button_state(state_machine);
            break;
        case WORKING:
            switch(state_working){
                case HEATER_WORK:
                    if (time_checkout_HEATER >= MAX_TIME_HEATER) state_machine = TIME_OUT;
                    HEATER = 1;
                    FAN2 = 1;
                    break;
                case HEATPUMB_WORK:
                    if (time_checkout_HEATPUMB >= MAX_TIME_HEATPUMB) state_machine = TIME_OUT;
                    HEATPUMB = 1;
                    FAN3 = 1;
                    break;
            }
            switch_button_state(state_machine);
            break;
        case TIME_OUT:
            time_checkout_HEATER = 0;
            time_checkout_HEATPUMB = 0;
            state_machine = IDLE;
            break;
    }
}
