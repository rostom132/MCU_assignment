
#include <pic18f8722.h>

#include "variables.h"
#include "pin_manager.h"
#include "register.h"
#include "button.h"
#include "time_manager.h"

void read_button_A(void){
    first_read_A = second_read_A;
    second_read_A = BUTTON_TRIG;
    if (first_read_A == second_read_A){
        if(second_read_A == 0) button = 1;
        else button = 2;
        return;
    }
    button = 0;
    return;
}

void switch_button_state(int type){
    switch(BUTTON_STATE){
        case 1:
            if (button == 1) BUTTON_STATE = 2;
            break;
        case 2:
            if (button == 2){
                if (type == IDLE){
                    state_machine = WORKING;
                    state_working = HEATER_WORK;
                    uint32_t temp = register_timer(0,TIME_SWAP_HEATER_HEATPUMB,swap_machine,1);
                    FAN1 = 1;
                }
                else {
                    time_checkout_HEATER = 0;
                    time_checkout_HEATPUMB = 0;
                    remove_timer(1);
                    //remove_timer(2);
                    HEATER = 0;
                    FAN2 = 0;
                    HEATPUMB = 0;
                    FAN3 = 0;
                    FAN1 = 0;
                    state_machine = IDLE;
                }
                BUTTON_STATE = 1;
            }
            break;
    }
    return;
}

