#ifndef _BUTTON_H_
#define _BUTTON_H_

void read_button_A(void);
void switch_button_state(int type);

#endif