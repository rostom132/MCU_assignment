#ifndef _DHT_H_
#define _DHT_H_

#define TIME_OUT_DHT 100

#define DHT_DATA_IN PORTDbits.RD0
#define DHT_DATA_OUT LATDbits.LATD0
#define DHT_DIRECTION TRISDbits.TRISD0

char FLAG_BUG = 0;
int temperature_value = 0,
    humidity_value = 0;

char temperature_dht11[2];
char humidity_dht11[2];

void readTempAndHumid(void);

#endif
