/*
 * File:   display.c
 * Author: Dell
 *
 * Created on November 22, 2019, 5:26 PM
 */


#include "pin_manager.h"
#include "BBSPI_LCD.h"

void initial_display(void){
    mOPEN_LCD; 
    mLCD_CLEAR;
    mCURSOR_LINE1;
    LCDPutStr("DRY FOOD MACHINE");
    mCURSOR_LINE2;
    LCDPutStr("   ID:1752541   ");
    return;
}
