#include <xc.h>
#include <math.h>
#include "pin_manager.h"

void initial_SYSTEM (void){
    OSCCON = OSCCON_SETTING;
    OSCTUNE = 0x0F;
    BUTTON_TRIG_DIR = 1;
    BUTTON_TRIG = 1;
    LED_DISPLAY_DIR = 0x00;
    LED_DISPLAY_INIT = 0x00;
    ADCON1 = 0b00001111;
    initial_display();
}


