/*
 * File:   main.c
 * Author: Dell
 * Created on October 5, 2019, 10:44 AM
 */
#include <xc.h>
#include <pic18f8722.h>
#include "driver.h"
#include "variables.h"
#include "pin_manager.h"
#include "register.h"
#include "BBSPI_LCD.h"
#include "FSM.h"
#include "dht.h"


void __interrupt() main_interrupt(void){
    if (INTCONbits.TMR0IE && INTCONbits.TMR0IF ){
        //count_count ++;
        if (ALLOW_TIMER_REGISTER == 1){
            int temp = timer_ISR();
        }
        INTCONbits.TMR0IF = 0;
        TMR0L = 0xFFFF -  TIME_INTERUPT;
        TMR0H = (0xFFFF - TIME_INTERUPT)>>8;
        if (state_machine == WORKING && state_working == HEATER_WORK){
            time_checkout_HEATER++;
        }
        else if (state_machine == WORKING && state_working == HEATPUMB_WORK){
            time_checkout_HEATPUMB++;
        }
    }
}


void main(void) {
    initial_SYSTEM();
    initial_register();
    start_timer(TIMER_TMR0);
    
    while(1){
        readTempAndHumid();
        __delay_ms(500);
        if (temperature_value > 0) LATD++;
//        FLAG_BUG = 1;
//        __delay_ms(3000);
//        LATD ++;
//        FLAG_BUG = 0;
        //dispatch();
        //FSM();
        //LATDbits.LATD0 = ~LATDbits.LATD0;
        //__delay_ms(5000);
    }
}
