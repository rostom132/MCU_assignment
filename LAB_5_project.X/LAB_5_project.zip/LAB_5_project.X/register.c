#include <xc.h>
#include <pic18f8722.h>
#include "register.h"
#include "driver.h"
#include "pin_manager.h"
#include "variables.h"
#include "button.h"

void swap_machine(void){
    if (state_working == HEATER_WORK){
        time_checkout_HEATER = 0;
        HEATER = 0;
        FAN2 = 0;
        state_working = HEATPUMB_WORK;
        return;
    }
    time_checkout_HEATPUMB = 0;
    HEATPUMB = 0;
    FAN3 = 0;
    state_working = HEATER_WORK;
    return;
}

void initial_register(void){
    uint32_t temp = register_timer(0,10,read_button_A,NULL);
}

