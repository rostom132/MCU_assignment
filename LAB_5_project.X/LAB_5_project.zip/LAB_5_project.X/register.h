#ifndef _REGISTER_H_
#define _REGISTER_H_

void swap_machine(void);
void initial_register(void);

#endif