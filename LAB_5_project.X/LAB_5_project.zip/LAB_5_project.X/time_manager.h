#ifndef TIME_MANAGER_H
#define TIME_MANAGER_H

#define INTERUPT_PERIOD     10                       // 10 millis second

#define TIME_SWAP_HEATER_HEATPUMB         5000
#define MAX_TIME_HEATER     6000/INTERUPT_PERIOD        
#define MAX_TIME_HEATPUMB   6000/INTERUPT_PERIOD

#endif