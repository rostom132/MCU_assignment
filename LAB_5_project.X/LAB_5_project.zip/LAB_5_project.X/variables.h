#ifndef _VARIABLES_H_
#define _VARIABLES_H_

#include "driver.h"
//#define _XTAL_FREQ 2000000

typedef unsigned char BYTE_1;

BYTE_1 first_read_A = 1;
BYTE_1 second_read_A = 0;
BYTE_1 button = 0;
BYTE_1 BUTTON_STATE = 1;

enum state {IDLE, WORKING, TIME_OUT};
enum state state_machine;

enum state_work {HEATER_WORK, HEATPUMB_WORK};
enum state_work state_working;

int time_checkout_HEATER = 0,
    time_checkout_HEATPUMB = 0;

int remove_tasks =0;
int NUMBER_EXIST = 0;
int NUMBER_EXIST_TASKS = 0;
int HEAD_QUEUE = 0;
unsigned char ALLOW_TIMER_REGISTER = 0;
unsigned long long int time = 0;

int HEAD_ARRAY = 0;
int count_count = 0;
int ledVal = 0;

typedef struct{    
    timer_callback_t callback;
    uint64_t delay;
    uint64_t period;
    void* data;
    int next;
} sTask;

int execution[NUMBER_TASK] = {0};
sTask tasks[NUMBER_TASK];

enum Timer_type {TIMER_TMR0, TIMER_TMR1, TIMER_TMR2, TIMER_TMR3, TIMER_TMR4};

#endif